import { useCallback, useEffect, useMemo, useState } from "react";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";
const emptyForm = { title: "", description: "", priority: "Medium", status: "Todo", dueDate: "" };

function formatDate(value) {
  if (!value) return "No due date";
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? "No due date"
    : date.toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
}

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  // Auth state
  const [currentUser, setCurrentUser] = useState(() => {
    try {
      const stored = localStorage.getItem("novaboard_user");
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });
  const [token, setToken] = useState(() => localStorage.getItem("novaboard_token") || "");
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState("login"); // 'login' | 'register'
  const [authData, setAuthData] = useState({ name: "", email: "", password: "" });
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState("");

  const request = useCallback(
    async (path, options = {}) => {
      const headers = {
        "Content-Type": "application/json",
        ...(options.headers || {})
      };
      if (token) {
        headers["Authorization"] = `Bearer ${token}`;
      }

      const response = await fetch(`${API_URL}${path}`, {
        ...options,
        headers
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(payload.message || "Request failed. Check backend status.");
      }
      return payload;
    },
    [token]
  );

  const loadTasks = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const payload = await request("/tasks");
      setTasks(payload.data || []);
    } catch (err) {
      setError(`${err.message} (Verify backend at http://localhost:5000 and MongoDB at mongodb://localhost:27017/nova-board)`);
    } finally {
      setLoading(false);
    }
  }, [request]);

  useEffect(() => {
    loadTasks();
  }, [loadTasks]);

  const visibleTasks = useMemo(() => {
    const query = search.trim().toLowerCase();
    return tasks.filter((task) => {
      const matchesStatus = filter === "All" || task.status === filter;
      const matchesSearch =
        !query || `${task.title} ${task.description}`.toLowerCase().includes(query);
      return matchesStatus && matchesSearch;
    });
  }, [tasks, search, filter]);

  const counts = useMemo(
    () => ({
      total: tasks.length,
      active: tasks.filter((task) => task.status === "In Progress").length,
      completed: tasks.filter((task) => task.status === "Completed").length
    }),
    [tasks]
  );

  function changeField(event) {
    setForm((current) => ({ ...current, [event.target.name]: event.target.value }));
  }

  async function createTask(event) {
    event.preventDefault();
    setSaving(true);
    setError("");
    setNotice("");
    try {
      await request("/tasks", {
        method: "POST",
        body: JSON.stringify({ ...form, dueDate: form.dueDate || null })
      });
      setForm(emptyForm);
      setNotice("Task saved successfully to MongoDB (database: nova-board).");
      await loadTasks();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function updateStatus(task, status) {
    setError("");
    setNotice("");
    try {
      const payload = await request(`/tasks/${task._id}`, {
        method: "PATCH",
        body: JSON.stringify({ status })
      });
      setTasks((current) =>
        current.map((item) => (item._id === task._id ? payload.data : item))
      );
      setNotice(`Task status updated to "${status}".`);
    } catch (err) {
      setError(err.message);
    }
  }

  async function deleteTask(task) {
    if (!window.confirm(`Delete "${task.title}"? This cannot be undone.`)) return;
    setError("");
    setNotice("");
    try {
      await request(`/tasks/${task._id}`, { method: "DELETE" });
      setTasks((current) => current.filter((item) => item._id !== task._id));
      setNotice("Task deleted from MongoDB.");
    } catch (err) {
      setError(err.message);
    }
  }

  // Auth Handlers
  async function handleAuthSubmit(e) {
    e.preventDefault();
    setAuthLoading(true);
    setAuthError("");
    const endpoint = authMode === "login" ? "/auth/login" : "/auth/register";

    try {
      const payload = await request(endpoint, {
        method: "POST",
        body: JSON.stringify(authData)
      });

      if (payload.token && payload.user) {
        setToken(payload.token);
        setCurrentUser(payload.user);
        localStorage.setItem("novaboard_token", payload.token);
        localStorage.setItem("novaboard_user", JSON.stringify(payload.user));
        setShowAuthModal(false);
        setNotice(`Welcome back, ${payload.user.name}!`);
        setAuthData({ name: "", email: "", password: "" });
        await loadTasks();
      }
    } catch (err) {
      setAuthError(err.message);
    } finally {
      setAuthLoading(false);
    }
  }

  function handleLogout() {
    setToken("");
    setCurrentUser(null);
    localStorage.removeItem("novaboard_token");
    localStorage.removeItem("novaboard_user");
    setNotice("You have logged out.");
    loadTasks();
  }

  return (
    <main className="app-shell">
      {/* Top Navigation Bar */}
      <header className="topbar">
        <a className="brand" href="/" aria-label="Nova Board home">
          <span className="brand-mark">N</span>
          <span>
            nova<span className="brand-light">board</span>
            <small>WORKFLOW HUB</small>
          </span>
        </a>

        <div className="topbar-right">
          <div className="compass-badge" title="Connect using MongoDB Compass">
            <span className="compass-icon">🧭</span>
            <span>Compass: mongodb://localhost:27017</span>
          </div>

          <span className="topbar-divider">/</span>

          {currentUser ? (
            <div className="user-menu">
              <div className="user-badge">
                <span className="user-avatar">{currentUser.name.charAt(0).toUpperCase()}</span>
                <span>{currentUser.name}</span>
              </div>
              <button className="btn-logout" onClick={handleLogout} type="button">
                Log Out
              </button>
            </div>
          ) : (
            <button
              className="btn-auth-top"
              onClick={() => {
                setAuthMode("login");
                setShowAuthModal(true);
              }}
              type="button"
            >
              Sign In / Register
            </button>
          )}
        </div>
      </header>

      {/* Hero Header */}
      <section className="hero">
        <div className="hero-copy">
          <p className="eyebrow">NOVA BOARD · CONNECTED TO MONGODB</p>
          <h1>
            Your work,<br />
            <span>in motion.</span>
          </h1>
          <p className="hero-subtitle">
            One focused space to capture tasks, manage workflows, and inspect your database live
            in MongoDB Compass with the <b>nova-board</b> database.
          </p>
          <div className="hero-pills">
            <span>↗ Localhost:5173</span>
            <span>◉ Compass: mongodb://localhost:27017</span>
            <span>✓ DB: nova-board</span>
          </div>
        </div>
        <div className="hero-art" aria-hidden="true">
          <div className="art-ring ring-one" />
          <div className="art-ring ring-two" />
          <div className="art-card card-back">
            <span>DATABASE SYNC</span>
            <div className="mini-bars">
              <i />
              <i />
              <i />
              <i />
              <i />
              <i />
            </div>
          </div>
          <div className="art-card card-front">
            <span className="art-check">✓</span>
            <div>
              <b>Nova Board Active</b>
              <small>Connected with MongoDB.</small>
            </div>
            <span className="art-arrow">↗</span>
          </div>
          <div className="art-orb">N</div>
        </div>
      </section>

      {/* Metrics Row */}
      <section className="stats-grid" aria-label="Task summary">
        <div className="stat-card">
          <span className="stat-label">TOTAL TASKS</span>
          <strong>{counts.total.toString().padStart(2, "0")}</strong>
          <span className="stat-foot">Database collection: tasks</span>
        </div>
        <div className="stat-card stat-active">
          <span className="stat-label">IN PROGRESS</span>
          <strong>{counts.active.toString().padStart(2, "0")}</strong>
          <span className="stat-foot">
            <i className="tiny-dot" /> Work currently moving
          </span>
        </div>
        <div className="stat-card stat-done">
          <span className="stat-label">COMPLETED</span>
          <strong>{counts.completed.toString().padStart(2, "0")}</strong>
          <span className="stat-foot">Small wins add up</span>
        </div>
      </section>

      {/* Main Workspace */}
      <section className="workspace">
        <div className="section-heading">
          <div>
            <p className="eyebrow">
              {currentUser ? `LOGGED IN AS ${currentUser.name.toUpperCase()}` : "WORKSPACE"}
            </p>
            <h2>
              Task Workspace <span className="count-badge">{tasks.length}</span>
            </h2>
          </div>
          <span className="database-tag">
            <span className="live-dot" /> DATABASE: NOVA-BOARD
          </span>
        </div>

        {(error || notice) && (
          <div
            className={`message ${error ? "message-error" : "message-success"}`}
            role="status"
          >
            {error || notice}
          </div>
        )}

        <div className="workspace-grid">
          {/* Create Task Form */}
          <form className="create-panel" onSubmit={createTask}>
            <div className="panel-title">
              <span className="panel-icon">＋</span>
              <div>
                <h3>Create a Task</h3>
                <p>Save directly to MongoDB</p>
              </div>
            </div>

            <label htmlFor="title">
              Task Title <em>*</em>
            </label>
            <input
              id="title"
              name="title"
              value={form.title}
              onChange={changeField}
              placeholder="e.g. Set up MongoDB Nova Board"
              minLength="2"
              maxLength="100"
              required
            />

            <label htmlFor="description">Description</label>
            <textarea
              id="description"
              name="description"
              value={form.description}
              onChange={changeField}
              placeholder="What needs to get done?"
              rows="3"
              maxLength="1000"
            />

            <div className="form-row">
              <div>
                <label htmlFor="priority">Priority</label>
                <select id="priority" name="priority" value={form.priority} onChange={changeField}>
                  <option>Low</option>
                  <option>Medium</option>
                  <option>High</option>
                </select>
              </div>
              <div>
                <label htmlFor="dueDate">Due Date</label>
                <input
                  id="dueDate"
                  type="date"
                  name="dueDate"
                  value={form.dueDate}
                  onChange={changeField}
                />
              </div>
            </div>

            <button className="primary-button" disabled={saving}>
              {saving ? "Saving to MongoDB..." : "Add Task to Nova Board"} <span>↗</span>
            </button>
            <p className="form-note">
              <span>⌁</span> Persists to MongoDB URI: <b>mongodb://localhost:27017/nova-board</b>
            </p>
          </form>

          {/* Task Listing Panel */}
          <div className="tasks-panel">
            <div className="tasks-top">
              <div>
                <h3>All Tasks</h3>
                <p>Real-time workflow view</p>
              </div>
              <button
                className="refresh-button"
                onClick={loadTasks}
                type="button"
                title="Refresh tasks from MongoDB"
                aria-label="Refresh tasks"
              >
                ↻
              </button>
            </div>

            <div className="search-wrap">
              <span>⌕</span>
              <input
                aria-label="Search tasks"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search tasks by title or description..."
              />
            </div>

            <div className="filter-tabs" role="group" aria-label="Filter tasks">
              {["All", "Todo", "In Progress", "Completed"].map((status) => (
                <button
                  key={status}
                  className={filter === status ? "filter-tab selected" : "filter-tab"}
                  onClick={() => setFilter(status)}
                  type="button"
                >
                  {status}
                </button>
              ))}
            </div>

            <div className="task-list">
              {loading ? (
                <div className="empty-state">
                  <div className="empty-icon spin">↻</div>
                  <b>Loading tasks from database...</b>
                  <p>Connecting to mongodb://localhost:27017/nova-board</p>
                </div>
              ) : visibleTasks.length === 0 ? (
                <div className="empty-state">
                  <div className="empty-icon">✳</div>
                  <b>{tasks.length ? "No matching tasks" : "Nova Board is ready"}</b>
                  <p>
                    {tasks.length
                      ? "Try another filter or search keyword."
                      : "Create your first task on the left to see it in MongoDB Compass!"}
                  </p>
                </div>
              ) : (
                visibleTasks.map((task) => (
                  <article className="task-item" key={task._id}>
                    <div className={`task-priority priority-${task.priority.toLowerCase()}`} />
                    <div className="task-main">
                      <div className="task-title-row">
                        <h4>{task.title}</h4>
                        <span className={`priority-pill pill-${task.priority.toLowerCase()}`}>
                          {task.priority}
                        </span>
                      </div>
                      {task.description && (
                        <p className="task-description">{task.description}</p>
                      )}
                      <div className="task-meta">
                        <span>◷ {formatDate(task.dueDate)}</span>
                        <span className="created-meta">Added {formatDate(task.createdAt)}</span>
                      </div>
                    </div>
                    <div className="task-actions">
                      <select
                        aria-label={`Status for ${task.title}`}
                        value={task.status}
                        onChange={(e) => updateStatus(task, e.target.value)}
                      >
                        <option>Todo</option>
                        <option>In Progress</option>
                        <option>Completed</option>
                      </select>
                      <button
                        className="delete-button"
                        type="button"
                        onClick={() => deleteTask(task)}
                        aria-label={`Delete ${task.title}`}
                        title="Delete task"
                      >
                        ×
                      </button>
                    </div>
                  </article>
                ))
              )}
            </div>

            <div className="list-footer">
              <span>
                SHOWING <b>{visibleTasks.length}</b> OF <b>{tasks.length}</b> TASKS
              </span>
              <span>
                <i className="live-dot" /> COMPASS: <b>mongodb://localhost:27017</b> / <b>nova-board</b>
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer>
        <span>
          NOVA BOARD <b>·</b> FULL-STACK REACT + NODE.JS + MONGODB
        </span>
        <span>
          MongoDB Compass: <b>mongodb://localhost:27017</b> (Database: <b>nova-board</b>)
        </span>
      </footer>

      {/* Login & Registration Modal */}
      {showAuthModal && (
        <div className="modal-overlay" onClick={() => setShowAuthModal(false)}>
          <div className="modal-box" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <div className="modal-title">
                <span className="brand-mark">N</span>
                <div>
                  <h3>{authMode === "login" ? "Sign In to Nova Board" : "Create Account"}</h3>
                  <p>Access your personalized workspace</p>
                </div>
              </div>
              <button
                className="modal-close"
                onClick={() => setShowAuthModal(false)}
                type="button"
                aria-label="Close modal"
              >
                ×
              </button>
            </div>

            <div className="modal-tabs">
              <button
                className={`modal-tab ${authMode === "login" ? "active" : ""}`}
                onClick={() => {
                  setAuthMode("login");
                  setAuthError("");
                }}
                type="button"
              >
                Sign In
              </button>
              <button
                className={`modal-tab ${authMode === "register" ? "active" : ""}`}
                onClick={() => {
                  setAuthMode("register");
                  setAuthError("");
                }}
                type="button"
              >
                Create Account
              </button>
            </div>

            <form onSubmit={handleAuthSubmit}>
              <div className="modal-body">
                {authError && <div className="message message-error">{authError}</div>}

                {authMode === "register" && (
                  <div>
                    <label htmlFor="auth-name">Your Full Name</label>
                    <input
                      id="auth-name"
                      type="text"
                      placeholder="e.g. Alex Nova"
                      value={authData.name}
                      onChange={(e) =>
                        setAuthData({ ...authData, name: e.target.value })
                      }
                      required
                    />
                  </div>
                )}

                <label htmlFor="auth-email">Email Address</label>
                <input
                  id="auth-email"
                  type="email"
                  placeholder="name@example.com"
                  value={authData.email}
                  onChange={(e) =>
                    setAuthData({ ...authData, email: e.target.value })
                  }
                  required
                />

                <label htmlFor="auth-password">Password</label>
                <input
                  id="auth-password"
                  type="password"
                  placeholder="At least 6 characters"
                  minLength="6"
                  value={authData.password}
                  onChange={(e) =>
                    setAuthData({ ...authData, password: e.target.value })
                  }
                  required
                />
              </div>

              <div className="modal-footer">
                <button className="primary-button" disabled={authLoading}>
                  {authLoading
                    ? "Authenticating..."
                    : authMode === "login"
                    ? "Sign In ↗"
                    : "Create Account ↗"}
                </button>
                <button
                  className="btn-guest"
                  type="button"
                  onClick={() => setShowAuthModal(false)}
                >
                  Continue as Guest
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </main>
  );
}
