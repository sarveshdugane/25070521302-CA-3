const express = require("express");
const mongoose = require("mongoose");
const Task = require("../models/Task");
const { optionalAuth } = require("../middleware/auth");

const router = express.Router();
router.use(optionalAuth);

// Fallback in-memory store if MongoDB is currently offline
let fallbackTasks = [
  {
    _id: "6710c0a1b89ef12345678901",
    title: "Connect with MongoDB Compass",
    description: "Open MongoDB Compass and paste connection string: mongodb://localhost:27017, then view the nova-board database.",
    priority: "High",
    status: "Todo",
    dueDate: new Date(Date.now() + 86400000 * 2).toISOString(),
    createdAt: new Date().toISOString(),
    user: null
  },
  {
    _id: "6710c0a1b89ef12345678902",
    title: "Verify Nova Board Login & Registration",
    description: "Create an account or sign in with your email and password to personalize your task board.",
    priority: "Medium",
    status: "In Progress",
    dueDate: new Date(Date.now() + 86400000 * 5).toISOString(),
    createdAt: new Date().toISOString(),
    user: null
  }
];

// GET /api/tasks
router.get("/", async (req, res, next) => {
  try {
    if (mongoose.connection.readyState === 1) {
      const filter = {};
      if (req.user) {
        filter.$or = [{ user: req.user.id }, { user: null }];
      }
      if (["Todo", "In Progress", "Completed"].includes(req.query.status)) {
        filter.status = req.query.status;
      }
      if (req.query.search && req.query.search.trim()) {
        const escaped = req.query.search.trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        const searchCondition = [
          { title: { $regex: escaped, $options: "i" } },
          { description: { $regex: escaped, $options: "i" } }
        ];
        if (filter.$or) {
          filter.$and = [{ $or: filter.$or }, { $or: searchCondition }];
          delete filter.$or;
        } else {
          filter.$or = searchCondition;
        }
      }
      const tasks = await Task.find(filter).sort({ createdAt: -1 });
      return res.json({ success: true, count: tasks.length, data: tasks });
    }

    // Fallback store
    let filtered = [...fallbackTasks];
    if (req.user) {
      filtered = filtered.filter((t) => !t.user || t.user === req.user.id);
    }
    if (["Todo", "In Progress", "Completed"].includes(req.query.status)) {
      filtered = filtered.filter((t) => t.status === req.query.status);
    }
    if (req.query.search && req.query.search.trim()) {
      const q = req.query.search.trim().toLowerCase();
      filtered = filtered.filter(
        (t) =>
          (t.title && t.title.toLowerCase().includes(q)) ||
          (t.description && t.description.toLowerCase().includes(q))
      );
    }
    res.json({ success: true, count: filtered.length, data: filtered });
  } catch (error) {
    next(error);
  }
});

// POST /api/tasks
router.post("/", async (req, res, next) => {
  try {
    const { title, description, priority, status, dueDate } = req.body;

    if (!title || title.trim().length < 2) {
      return res.status(400).json({ success: false, message: "Title must be at least 2 characters." });
    }

    if (mongoose.connection.readyState === 1) {
      const task = await Task.create({
        title: title.trim(),
        description: description || "",
        priority: priority || "Medium",
        status: status || "Todo",
        dueDate: dueDate ? new Date(dueDate) : null,
        user: req.user ? req.user.id : null
      });
      return res.status(201).json({ success: true, data: task });
    }

    // Fallback store
    const newTask = {
      _id: new mongoose.Types.ObjectId().toString(),
      title: title.trim(),
      description: description || "",
      priority: priority || "Medium",
      status: status || "Todo",
      dueDate: dueDate ? new Date(dueDate).toISOString() : null,
      createdAt: new Date().toISOString(),
      user: req.user ? req.user.id : null
    };
    fallbackTasks.unshift(newTask);
    res.status(201).json({ success: true, data: newTask });
  } catch (error) {
    next(error);
  }
});

// PATCH /api/tasks/:id
router.patch("/:id", async (req, res, next) => {
  try {
    if (mongoose.connection.readyState === 1) {
      if (!mongoose.isValidObjectId(req.params.id)) {
        return res.status(400).json({ success: false, message: "Invalid task ID." });
      }
      const allowed = ["title", "description", "priority", "status", "dueDate"];
      const update = {};
      for (const key of allowed) {
        if (Object.prototype.hasOwnProperty.call(req.body, key)) {
          update[key] = key === "dueDate" && req.body[key] ? new Date(req.body[key]) : req.body[key];
        }
      }
      const task = await Task.findByIdAndUpdate(req.params.id, update, {
        new: true,
        runValidators: true
      });
      if (!task) return res.status(404).json({ success: false, message: "Task not found." });
      return res.json({ success: true, data: task });
    }

    // Fallback store
    const index = fallbackTasks.findIndex((t) => t._id.toString() === req.params.id);
    if (index === -1) {
      return res.status(404).json({ success: false, message: "Task not found." });
    }
    fallbackTasks[index] = { ...fallbackTasks[index], ...req.body };
    res.json({ success: true, data: fallbackTasks[index] });
  } catch (error) {
    next(error);
  }
});

// DELETE /api/tasks/:id
router.delete("/:id", async (req, res, next) => {
  try {
    if (mongoose.connection.readyState === 1) {
      if (!mongoose.isValidObjectId(req.params.id)) {
        return res.status(400).json({ success: false, message: "Invalid task ID." });
      }
      const task = await Task.findByIdAndDelete(req.params.id);
      if (!task) return res.status(404).json({ success: false, message: "Task not found." });
      return res.json({ success: true, message: "Task deleted." });
    }

    // Fallback store
    const initialLength = fallbackTasks.length;
    fallbackTasks = fallbackTasks.filter((t) => t._id.toString() !== req.params.id);
    if (fallbackTasks.length === initialLength) {
      return res.status(404).json({ success: false, message: "Task not found." });
    }
    res.json({ success: true, message: "Task deleted." });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
