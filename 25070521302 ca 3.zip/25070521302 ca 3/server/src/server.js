require("dotenv").config();
const express = require("express");
const cors = require("cors");
const connectDB = require("./config/db");
const taskRoutes = require("./routes/taskRoutes");
const authRoutes = require("./routes/authRoutes");
const mongoose = require("mongoose");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors({
  origin: process.env.CLIENT_ORIGIN || "http://localhost:5173",
  credentials: true
}));
app.use(express.json({ limit: "1mb" }));

app.get("/api/health", (_req, res) => {
  const isDbConnected = mongoose.connection.readyState === 1;
  res.json({
    success: true,
    message: "Nova Board API is running.",
    database: isDbConnected ? "connected" : "connecting/disconnected",
    compassUri: "mongodb://localhost:27017",
    databaseName: "nova-board"
  });
});

app.use("/api/auth", authRoutes);
app.use("/api/tasks", taskRoutes);

app.use((req, res) => {
  res.status(404).json({ success: false, message: `Route not found: ${req.method} ${req.originalUrl}` });
});

app.use((error, _req, res, _next) => {
  console.error(error);
  if (error.name === "ValidationError" || error.name === "CastError") {
    return res.status(400).json({ success: false, message: error.message });
  }
  if (error.code === 11000) {
    return res.status(409).json({ success: false, message: "An account with this email already exists." });
  }
  if (error.name === "MongoServerSelectionError") {
    return res.status(503).json({
      success: false,
      message: "Database connecting or unavailable. Check that MongoDB Server is running on port 27017."
    });
  }
  res.status(500).json({ success: false, message: "Internal server error." });
});

// Start Express server and connect to database
connectDB().finally(() => {
  app.listen(PORT, () => {
    console.log(`=======================================================`);
    console.log(`🚀 Nova Board Backend running at: http://localhost:${PORT}`);
    console.log(`📡 MongoDB Compass URI: mongodb://localhost:27017`);
    console.log(`📂 Database Name: nova-board`);
    console.log(`🔗 API Health: http://localhost:${PORT}/api/health`);
    console.log(`=======================================================`);
  });
});
