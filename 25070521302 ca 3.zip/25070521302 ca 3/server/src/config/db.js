const mongoose = require("mongoose");

let isConnecting = false;
let hasLoggedFailure = false;

async function attemptConnect(uri) {
  return mongoose.connect(uri, {
    dbName: "nova-board",
    serverSelectionTimeoutMS: 3000,
    connectTimeoutMS: 3000
  });
}

async function connectDB() {
  const primaryUri = process.env.MONGODB_URI || "mongodb://localhost:27017";
  const fallbackUri = primaryUri.includes("localhost")
    ? primaryUri.replace("localhost", "127.0.0.1")
    : null;

  async function tryConnect(isSilent = false) {
    if (isConnecting || mongoose.connection.readyState === 1) return;
    isConnecting = true;

    try {
      await attemptConnect(primaryUri);
      console.log(`[MongoDB] Connected successfully: ${mongoose.connection.host}/${mongoose.connection.name}`);
      console.log(`[MongoDB Compass] Connect using URI: mongodb://localhost:27017 | Database: nova-board`);
      hasLoggedFailure = false;
    } catch (err) {
      if (fallbackUri) {
        try {
          await attemptConnect(fallbackUri);
          console.log(`[MongoDB] Connected successfully via 127.0.0.1: ${mongoose.connection.host}/${mongoose.connection.name}`);
          console.log(`[MongoDB Compass] Connect using URI: mongodb://localhost:27017 | Database: nova-board`);
          hasLoggedFailure = false;
          isConnecting = false;
          return;
        } catch (_fallbackErr) {
          // fall through
        }
      }

      if (!hasLoggedFailure && !isSilent) {
        hasLoggedFailure = true;
        console.warn(`[MongoDB Status] MongoDB connection at ${primaryUri} is waiting for MongoDB Server service.`);
        console.warn(`[MongoDB Compass] In Compass, connect using: mongodb://localhost:27017 (Database: nova-board).`);
        console.warn(`[MongoDB Note] If Compass shows ECONNREFUSED, start MongoDB Community Server in Windows Services.`);
      }
    } finally {
      isConnecting = false;
    }
  }

  // Initial connection attempt
  await tryConnect(false);

  // Background reconnect every 5s so when MongoDB starts, it connects instantly
  setInterval(() => {
    if (mongoose.connection.readyState === 0) {
      tryConnect(true);
    }
  }, 5000);
}

module.exports = connectDB;
