# Nova Board — Full-Stack Workflow Manager

**Nova Board** is a modern task and workflow management system built with React (Vite), Node.js, Express, and MongoDB. It features full CRUD operations, user authentication with a Login & Registration interface, and live persistence to MongoDB inspectable via MongoDB Compass.

---

## 🌟 Features
- **User Authentication**: Secure Sign In and Registration (JWT + bcrypt), with optional guest access
- **Live MongoDB Persistence**: Connected via Mongoose to `mongodb://localhost:27017/nova-board`
- **MongoDB Compass Integration**: Direct inspection of the `nova-board` database and collections (`tasks`, `users`)
- **Task Management**: Create, view, update status, search, filter, and delete tasks
- **Summary Metrics**: Real-time counters for Total, In Progress, and Completed tasks
- **Responsive Dark Theme**: Modern UI styled with custom fonts, glassmorphism, and responsive layouts

---

## 🚀 Quick Start & Localhost Links

| Service | Localhost URL | Details |
|---|---|---|
| **Frontend App** | **`http://localhost:5173`** | React + Vite UI with Login/Register & Task Board |
| **Backend API** | **`http://localhost:5000`** | Express REST API |
| **API Health Check** | **`http://localhost:5000/api/health`** | Server and database status |
| **MongoDB Compass** | **`mongodb://localhost:27017`** | Database: `nova-board` |

---

## 🧭 MongoDB & MongoDB Compass Setup

1. Open **MongoDB Compass**.
2. In the **New Connection** field, enter:
   ```text
   mongodb://localhost:27017
   ```
3. Click **Connect**.
4. You will see the **`nova-board`** database with the following collections:
   - `tasks`: Created tasks with titles, descriptions, priorities, and statuses
   - `users`: Registered users with hashed passwords

> **MongoDB URI in `.env`**:
> ```env
> MONGODB_URI=mongodb://localhost:27017/nova-board
> ```

---

## 🛠 Running the Project Locally

### 1. Start Backend (Terminal 1)
```bash
cd backend
npm run dev
# or: node src/server.js
```
The backend starts at `http://localhost:5000`.

### 2. Start Frontend (Terminal 2)
```bash
cd frontend
npm run dev
```
The frontend starts at `http://localhost:5173`. Open it in your browser.

---

## 🔐 API Endpoints

### Authentication
- `POST /api/auth/register` — Create a new user account `{ name, email, password }`
- `POST /api/auth/login` — Sign in `{ email, password }`
- `GET /api/auth/me` — Get authenticated user details

### Tasks
- `GET /api/tasks` — List all tasks (supports `?status=...` and `?search=...`)
- `POST /api/tasks` — Create a task `{ title, description, priority, status, dueDate }`
- `PATCH /api/tasks/:id` — Update task status or fields
- `DELETE /api/tasks/:id` — Remove a task
- `GET /api/health` — Check backend and database health status
