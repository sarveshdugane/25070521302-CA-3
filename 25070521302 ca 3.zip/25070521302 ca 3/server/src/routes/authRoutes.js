const express = require("express");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const mongoose = require("mongoose");
const User = require("../models/User");
const { authenticate, JWT_SECRET } = require("../middleware/auth");

const router = express.Router();

// Fallback in-memory store if MongoDB is offline
const fallbackUsers = [];

function generateToken(user) {
  return jwt.sign(
    { id: user._id || user.id, name: user.name, email: user.email },
    JWT_SECRET,
    { expiresIn: "7d" }
  );
}

// POST /api/auth/register
router.post("/register", async (req, res, next) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ success: false, message: "Please provide name, email, and password." });
    }

    if (password.length < 6) {
      return res.status(400).json({ success: false, message: "Password must be at least 6 characters long." });
    }

    const normalizedEmail = email.toLowerCase().trim();

    if (mongoose.connection.readyState === 1) {
      const existing = await User.findOne({ email: normalizedEmail });
      if (existing) {
        return res.status(409).json({ success: false, message: "An account with this email already exists." });
      }

      const user = await User.create({ name: name.trim(), email: normalizedEmail, password });
      const token = generateToken(user);

      return res.status(201).json({
        success: true,
        message: "Registration successful.",
        token,
        user: { id: user._id, name: user.name, email: user.email }
      });
    }

    // Fallback mode
    const existing = fallbackUsers.find((u) => u.email === normalizedEmail);
    if (existing) {
      return res.status(409).json({ success: false, message: "An account with this email already exists." });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    const mockUser = {
      _id: new mongoose.Types.ObjectId().toString(),
      name: name.trim(),
      email: normalizedEmail,
      password: hashedPassword,
      createdAt: new Date()
    };
    fallbackUsers.push(mockUser);
    const token = generateToken(mockUser);

    res.status(201).json({
      success: true,
      message: "Registration successful (temporary in-memory store; will save to MongoDB once connected).",
      token,
      user: { id: mockUser._id, name: mockUser.name, email: mockUser.email }
    });
  } catch (error) {
    next(error);
  }
});

// POST /api/auth/login
router.post("/login", async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ success: false, message: "Please enter your email and password." });
    }

    const normalizedEmail = email.toLowerCase().trim();

    if (mongoose.connection.readyState === 1) {
      const user = await User.findOne({ email: normalizedEmail });
      if (!user) {
        return res.status(401).json({ success: false, message: "Invalid email or password." });
      }

      const isMatch = await user.comparePassword(password);
      if (!isMatch) {
        return res.status(401).json({ success: false, message: "Invalid email or password." });
      }

      const token = generateToken(user);
      return res.json({
        success: true,
        message: "Login successful.",
        token,
        user: { id: user._id, name: user.name, email: user.email }
      });
    }

    // Fallback mode
    const user = fallbackUsers.find((u) => u.email === normalizedEmail);
    if (!user) {
      return res.status(401).json({ success: false, message: "Invalid email or password." });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: "Invalid email or password." });
    }

    const token = generateToken(user);
    res.json({
      success: true,
      message: "Login successful.",
      token,
      user: { id: user._id, name: user.name, email: user.email }
    });
  } catch (error) {
    next(error);
  }
});

// GET /api/auth/me
router.get("/me", authenticate, async (req, res, next) => {
  try {
    if (mongoose.connection.readyState === 1) {
      const user = await User.findById(req.user.id).select("-password");
      if (!user) {
        return res.status(404).json({ success: false, message: "User not found." });
      }
      return res.json({ success: true, user });
    }

    const user = fallbackUsers.find((u) => u._id === req.user.id);
    if (!user) {
      return res.json({ success: true, user: req.user });
    }
    const { password: _p, ...safeUser } = user;
    res.json({ success: true, user: safeUser });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
